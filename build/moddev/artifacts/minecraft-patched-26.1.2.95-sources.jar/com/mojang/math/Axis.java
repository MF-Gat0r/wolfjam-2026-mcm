package com.mojang.math;

import org.joml.Quaternionf;
import org.joml.Vector3f;

@FunctionalInterface
public interface Axis {
    Axis XN = angle -> new Quaternionf().rotationX(-angle);
    Axis XP = angle -> new Quaternionf().rotationX(angle);
    Axis YN = angle -> new Quaternionf().rotationY(-angle);
    Axis YP = angle -> new Quaternionf().rotationY(angle);
    Axis ZN = angle -> new Quaternionf().rotationZ(-angle);
    Axis ZP = angle -> new Quaternionf().rotationZ(angle);

    static Axis of(Vector3f vector) {
        return angle -> new Quaternionf().rotationAxis(angle, vector);
    }

    Quaternionf rotation(float angle);

    default Quaternionf rotationDegrees(float angle) {
        return this.rotation(angle * (float) (Math.PI / 180.0));
    }
}
