package com.mojang.blaze3d.vertex;

import java.nio.ByteOrder;
import java.util.stream.Collectors;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;
import org.lwjgl.system.MemoryUtil;

@OnlyIn(Dist.CLIENT)
public class BufferBuilder implements VertexConsumer {
    private static final int MAX_VERTEX_COUNT = 16777215;
    private static final long NOT_BUILDING = -1L;
    private static final long UNKNOWN_ELEMENT = -1L;
    private static final boolean IS_LITTLE_ENDIAN = ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN;
    private final ByteBufferBuilder buffer;
    private long vertexPointer = -1L;
    private int vertices;
    private final VertexFormat format;
    private final VertexFormat.Mode mode;
    private final boolean fastFormat;
    private final boolean fullFormat;
    private final int vertexSize;
    private final int initialElementsToFill;
    private final int[] offsetsByElement;
    private int elementsToFill;
    private boolean building = true;

    public BufferBuilder(ByteBufferBuilder buffer, VertexFormat.Mode mode, VertexFormat format) {
        if (!format.contains(VertexFormatElement.POSITION)) {
            throw new IllegalArgumentException("Cannot build mesh with no position element");
        } else {
            this.buffer = buffer;
            this.mode = mode;
            this.format = format;
            this.vertexSize = format.getVertexSize();
            this.initialElementsToFill = format.getElementsMask() & ~VertexFormatElement.POSITION.mask();
            this.offsetsByElement = format.getOffsetsByElement();
            boolean isFullFormat = format == DefaultVertexFormat.ENTITY;
            boolean isBlockFormat = format == DefaultVertexFormat.BLOCK;
            this.fastFormat = isFullFormat || isBlockFormat;
            this.fullFormat = isFullFormat;
        }
    }

    public @Nullable MeshData build() {
        this.ensureBuilding();
        this.endLastVertex();
        MeshData mesh = this.storeMesh();
        this.building = false;
        this.vertexPointer = -1L;
        return mesh;
    }

    public MeshData buildOrThrow() {
        MeshData buffer = this.build();
        if (buffer == null) {
            throw new IllegalStateException("BufferBuilder was empty");
        } else {
            return buffer;
        }
    }

    private void ensureBuilding() {
        if (!this.building) {
            throw new IllegalStateException("Not building!");
        }
    }

    private @Nullable MeshData storeMesh() {
        if (this.vertices == 0) {
            return null;
        } else {
            ByteBufferBuilder.Result vertexBuffer = this.buffer.build();
            if (vertexBuffer == null) {
                return null;
            } else {
                int indices = this.mode.indexCount(this.vertices);
                VertexFormat.IndexType indexType = VertexFormat.IndexType.least(this.vertices);
                return new MeshData(vertexBuffer, new MeshData.DrawState(this.format, this.vertices, indices, this.mode, indexType));
            }
        }
    }

    private long beginVertex() {
        this.ensureBuilding();
        this.endLastVertex();
        if (this.vertices >= 16777215) {
            throw new IllegalStateException("Trying to write too many vertices (>16777215) into BufferBuilder");
        } else {
            this.vertices++;
            long pointer = this.buffer.reserve(this.vertexSize);
            this.vertexPointer = pointer;
            return pointer;
        }
    }

    private long beginElement(VertexFormatElement element) {
        int oldElements = this.elementsToFill;
        int newElements = oldElements & ~element.mask();
        if (newElements == oldElements) {
            return -1L;
        } else {
            this.elementsToFill = newElements;
            long vertexPointer = this.vertexPointer;
            if (vertexPointer == -1L) {
                throw new IllegalArgumentException("Not currently building vertex");
            } else {
                return vertexPointer + this.offsetsByElement[element.id()];
            }
        }
    }

    private void endLastVertex() {
        if (this.vertices != 0) {
            if (this.elementsToFill != 0) {
                String missingElements = VertexFormatElement.elementsFromMask(this.elementsToFill)
                    .map(this.format::getElementName)
                    .collect(Collectors.joining(", "));
                throw new IllegalStateException("Missing elements in vertex: " + missingElements);
            } else {
                if (this.mode == VertexFormat.Mode.LINES) {
                    long pointer = this.buffer.reserve(this.vertexSize);
                    MemoryUtil.memCopy(pointer - this.vertexSize, pointer, this.vertexSize);
                    this.vertices++;
                }
            }
        }
    }

    private static void putRgba(long pointer, int argb) {
        int abgr = ARGB.toABGR(argb);
        MemoryUtil.memPutInt(pointer, IS_LITTLE_ENDIAN ? abgr : Integer.reverseBytes(abgr));
    }

    private static void putPackedUv(long pointer, int packedUv) {
        if (IS_LITTLE_ENDIAN) {
            MemoryUtil.memPutInt(pointer, packedUv);
        } else {
            MemoryUtil.memPutShort(pointer, (short)(packedUv & 65535));
            MemoryUtil.memPutShort(pointer + 2L, (short)(packedUv >> 16 & 65535));
        }
    }

    @Override
    public VertexConsumer addVertex(float x, float y, float z) {
        long pointer = this.beginVertex() + this.offsetsByElement[VertexFormatElement.POSITION.id()];
        this.elementsToFill = this.initialElementsToFill;
        MemoryUtil.memPutFloat(pointer, x);
        MemoryUtil.memPutFloat(pointer + 4L, y);
        MemoryUtil.memPutFloat(pointer + 8L, z);
        return this;
    }

    @Override
    public VertexConsumer setColor(int r, int g, int b, int a) {
        long pointer = this.beginElement(VertexFormatElement.COLOR);
        if (pointer != -1L) {
            MemoryUtil.memPutByte(pointer, (byte)r);
            MemoryUtil.memPutByte(pointer + 1L, (byte)g);
            MemoryUtil.memPutByte(pointer + 2L, (byte)b);
            MemoryUtil.memPutByte(pointer + 3L, (byte)a);
        }

        return this;
    }

    @Override
    public VertexConsumer setColor(int color) {
        long pointer = this.beginElement(VertexFormatElement.COLOR);
        if (pointer != -1L) {
            putRgba(pointer, color);
        }

        return this;
    }

    @Override
    public VertexConsumer setUv(float u, float v) {
        long pointer = this.beginElement(VertexFormatElement.UV0);
        if (pointer != -1L) {
            MemoryUtil.memPutFloat(pointer, u);
            MemoryUtil.memPutFloat(pointer + 4L, v);
        }

        return this;
    }

    @Override
    public VertexConsumer setUv1(int u, int v) {
        return this.uvShort((short)u, (short)v, VertexFormatElement.UV1);
    }

    @Override
    public VertexConsumer setOverlay(int packedOverlayCoords) {
        long pointer = this.beginElement(VertexFormatElement.UV1);
        if (pointer != -1L) {
            putPackedUv(pointer, packedOverlayCoords);
        }

        return this;
    }

    @Override
    public VertexConsumer setUv2(int u, int v) {
        return this.uvShort((short)u, (short)v, VertexFormatElement.UV2);
    }

    @Override
    public VertexConsumer setLight(int packedLightCoords) {
        long pointer = this.beginElement(VertexFormatElement.UV2);
        if (pointer != -1L) {
            putPackedUv(pointer, packedLightCoords);
        }

        return this;
    }

    private VertexConsumer uvShort(short u, short v, VertexFormatElement element) {
        long pointer = this.beginElement(element);
        if (pointer != -1L) {
            MemoryUtil.memPutShort(pointer, u);
            MemoryUtil.memPutShort(pointer + 2L, v);
        }

        return this;
    }

    @Override
    public VertexConsumer setNormal(float x, float y, float z) {
        long pointer = this.beginElement(VertexFormatElement.NORMAL);
        if (pointer != -1L) {
            MemoryUtil.memPutByte(pointer, normalIntValue(x));
            MemoryUtil.memPutByte(pointer + 1L, normalIntValue(y));
            MemoryUtil.memPutByte(pointer + 2L, normalIntValue(z));
        }

        return this;
    }

    @Override
    public VertexConsumer setLineWidth(float width) {
        long pointer = this.beginElement(VertexFormatElement.LINE_WIDTH);
        if (pointer != -1L) {
            MemoryUtil.memPutFloat(pointer, width);
        }

        return this;
    }

    private static byte normalIntValue(float c) {
        return (byte)((int)(Mth.clamp(c, -1.0F, 1.0F) * 127.0F) & 0xFF);
    }

    @Override
    public void addVertex(float x, float y, float z, int color, float u, float v, int overlayCoords, int lightCoords, float nx, float ny, float nz) {
        if (this.fastFormat) {
            long pointer = this.beginVertex();
            MemoryUtil.memPutFloat(pointer + 0L, x);
            MemoryUtil.memPutFloat(pointer + 4L, y);
            MemoryUtil.memPutFloat(pointer + 8L, z);
            putRgba(pointer + 12L, color);
            MemoryUtil.memPutFloat(pointer + 16L, u);
            MemoryUtil.memPutFloat(pointer + 20L, v);
            long lightStart;
            if (this.fullFormat) {
                putPackedUv(pointer + 24L, overlayCoords);
                lightStart = pointer + 28L;
            } else {
                lightStart = pointer + 24L;
            }

            putPackedUv(lightStart + 0L, lightCoords);
            if (this.fullFormat) {
                MemoryUtil.memPutByte(lightStart + 4L, normalIntValue(nx));
                MemoryUtil.memPutByte(lightStart + 5L, normalIntValue(ny));
                MemoryUtil.memPutByte(lightStart + 6L, normalIntValue(nz));
            }
        } else {
            VertexConsumer.super.addVertex(x, y, z, color, u, v, overlayCoords, lightCoords, nx, ny, nz);
        }
    }
}
