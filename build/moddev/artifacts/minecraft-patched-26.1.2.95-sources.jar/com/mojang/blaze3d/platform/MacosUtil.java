package com.mojang.blaze3d.platform;

import ca.weblite.objc.Client;
import ca.weblite.objc.NSObject;
import com.sun.jna.Pointer;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.Locale;
import java.util.Optional;
import net.minecraft.server.packs.resources.IoSupplier;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.lwjgl.glfw.GLFWNativeCocoa;

@OnlyIn(Dist.CLIENT)
public class MacosUtil {
    public static final boolean IS_MACOS = System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("mac");
    private static final int NS_RESIZABLE_WINDOW_MASK = 8;
    private static final int NS_FULL_SCREEN_WINDOW_MASK = 16384;

    public static void exitNativeFullscreen(Window window) {
        getNsWindow(window).filter(MacosUtil::isInNativeFullscreen).ifPresent(MacosUtil::toggleNativeFullscreen);
    }

    public static void clearResizableBit(Window window) {
        getNsWindow(window).ifPresent(nsWindow -> {
            long styleMask = getStyleMask(nsWindow);
            nsWindow.send("setStyleMask:", styleMask & -9L);
        });
    }

    private static Optional<NSObject> getNsWindow(Window window) {
        long nsWindow = GLFWNativeCocoa.glfwGetCocoaWindow(window.handle());
        return nsWindow != 0L ? Optional.of(new NSObject(new Pointer(nsWindow))) : Optional.empty();
    }

    private static boolean isInNativeFullscreen(NSObject nsWindow) {
        return (getStyleMask(nsWindow) & 16384L) != 0L;
    }

    private static long getStyleMask(NSObject nsWindow) {
        return (Long)nsWindow.sendRaw("styleMask");
    }

    private static void toggleNativeFullscreen(NSObject nsWindow) {
        nsWindow.send("toggleFullScreen:", Pointer.NULL);
    }

    public static void loadIcon(IoSupplier<InputStream> icon) throws IOException {
        try (InputStream iconStream = icon.get()) {
            String base64Icon = Base64.getEncoder().encodeToString(iconStream.readAllBytes());
            Client objc = Client.getInstance();
            Object data = objc.sendProxy("NSData", "alloc").send("initWithBase64Encoding:", base64Icon);
            Object image = objc.sendProxy("NSImage", "alloc").send("initWithData:", data);
            objc.sendProxy("NSApplication", "sharedApplication").send("setApplicationIconImage:", image);
        }
    }
}
