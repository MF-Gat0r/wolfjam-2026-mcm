/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wolfjammod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.wolfjammod.WolfjammodMod;

public class WolfjammodModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(WolfjammodMod.MODID);
	public static final DeferredItem<Item> ROOM_RESET;
	public static final DeferredItem<Item> CUSTOM_COLOR_BLOCK;
	public static final DeferredItem<Item> ROOM_ASSIGNER;
	public static final DeferredItem<Item> LAVA_BLOCK;
	static {
		ROOM_RESET = block(WolfjammodModBlocks.ROOM_RESET);
		CUSTOM_COLOR_BLOCK = block(WolfjammodModBlocks.CUSTOM_COLOR_BLOCK, new Item.Properties().fireResistant());
		ROOM_ASSIGNER = block(WolfjammodModBlocks.ROOM_ASSIGNER);
		LAVA_BLOCK = block(WolfjammodModBlocks.LAVA_BLOCK, new Item.Properties().fireResistant());
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}